# DyCMS
An other content management system

!["DyCMS"](https://raw.githubusercontent.com/cyberzilla/dycms/master/screen.png "DyCMS Screen")

DyCMS is a HTML Template based On AdminLTE, can easily transform into PHP CMS...

FEATURE:
Save Setting In Local Storage, Handle Many Tabs With Scroll, And Many More... Just Try It..

DEMO:
https://cyberzilla.github.io/dycms/index.html

DEVELOPER:
https://abu.dzakiyyah.com

LICENSE:
This Template Licensed Under MIT
